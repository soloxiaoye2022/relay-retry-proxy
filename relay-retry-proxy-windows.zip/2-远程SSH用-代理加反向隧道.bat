@echo off
chcp 65001 >nul
title relay-retry-proxy — 模式二：代理 + 反向隧道（Trae 远程 SSH 用，需服务器配合）
cd /d "%~dp0"
if not exist "relay-retry-proxy.env" (
  echo [!] 没找到 relay-retry-proxy.env，将使用内置默认值 http://127.0.0.1:4000
)
for /f "usebackq eol=# tokens=1,* delims==" %%A in ("relay-retry-proxy.env") do (
  if not "%%A"=="" if not "%%B"=="" set "%%A=%%B"
)
echo ==========================================
echo  模式二：代理 + 反向隧道（Trae 远程 SSH 用，需服务器配合）
echo  上游: %UPSTREAM%
echo ==========================================

start "relay-proxy" /min "%~dp0relay-retry-proxy-windows-amd64.exe" -config "%~dp0relay-retry-proxy.env"
timeout /t 2 >nul
echo [隧道] 服务器 127.0.0.1:%REMOTE_PORT%  --^>  本机 127.0.0.1:8443
echo [隧道] 断开会自动重连，关掉本窗口即停止
:loop
ssh -N -R %REMOTE_PORT%:127.0.0.1:8443 -o ExitOnForwardFailure=yes -o ServerAliveInterval=15 -o ServerAliveCountMax=3 -p %SSH_PORT% %SSH_USER%@%SSH_HOST%
echo [隧道] 已断开，5 秒后重连...
timeout /t 5 >nul
goto loop
