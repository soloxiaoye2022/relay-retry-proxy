@echo off
chcp 65001 >nul
title relay-retry-proxy — 模式一：只在本机跑代理（Trae 本地窗口）
cd /d "%~dp0"
if not exist "relay-retry-proxy.env" (
  echo [!] 没找到 relay-retry-proxy.env，将使用内置默认值 http://127.0.0.1:4000
)
for /f "usebackq eol=# tokens=1,* delims==" %%A in ("relay-retry-proxy.env") do (
  if not "%%A"=="" if not "%%B"=="" set "%%A=%%B"
)
echo ==========================================
echo  模式一：只在本机跑代理（Trae 本地窗口）
echo  上游: %UPSTREAM%
echo ==========================================

"%~dp0relay-retry-proxy-windows-amd64.exe" -config "%~dp0relay-retry-proxy.env"
echo.
echo [已退出] 按任意键关闭...
pause >nul
